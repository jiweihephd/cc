This is the directory where your program would find test input files (e.g., when we review your submission, this is the directory where we'll place our test input files in)
