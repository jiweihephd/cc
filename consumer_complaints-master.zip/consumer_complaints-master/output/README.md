This is the directory where your program would write out output files. (e.g., when we run your code, this is where we'd expect your program would write the expected output file)
